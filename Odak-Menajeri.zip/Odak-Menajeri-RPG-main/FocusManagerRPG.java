import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class FocusManagerRPG extends Application {

    // --- Oyuncu Verileri ---
    private int xp = 0;
    private int seviye = 1;

    // --- UI Bileşenleri ---
    private Label xpLabel;
    private Label seviyeLabel;
    private Label rutbeLabel;
    private Label karakterSembolLabel;
    private VBox gorevListesi;
    private ProgressBar xpBar;

    // --- Hatırlatıcı Listesi ---
    // Her hatırlatıcı için: [gorevAdi, hedefSaat, tetiklendimi]
    private final List<String[]> hatirlaticilar = new ArrayList<>();
    private Timer zamanSayici;

    // Karakter seçimi
    private String secilenKarakter = "Erkek";

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage sahne) {
        // Pencere kapanınca timer'ı durdur
        sahne.setOnCloseRequest(e -> {
            if (zamanSayici != null) zamanSayici.cancel();
        });

        sahne.setTitle("Odak Menajeri RPG");
        sahne.setScene(yeniSahneOlustur());
        sahne.setMinWidth(480);
        sahne.setMinHeight(650);
        sahne.show();

        zamanSayiciBaslat();
    }

    private Scene yeniSahneOlustur() {
        // Üst panel: karakter + istatistikler
        VBox ustPanel = karakterPaneliOlustur();

        // Orta: görev ekleme formu
        VBox formPanel = gorevFormuOlustur();

        // Alt: görev listesi
        VBox listePanel = gorevListesiPaneliOlustur();

        VBox anaLayout = new VBox(12, ustPanel, formPanel, listePanel);
        anaLayout.setPadding(new Insets(16));
        anaLayout.setStyle("-fx-background-color: #1a1a2e;");

        ScrollPane sarici = new ScrollPane(anaLayout);
        sarici.setFitToWidth(true);
        sarici.setStyle("-fx-background: #1a1a2e; -fx-background-color: #1a1a2e;");

        return new Scene(sarici, 480, 660);
    }

    private VBox karakterPaneliOlustur() {
        // Karakter sembolü (emoji tabanlı, internet gerektirmez)
        karakterSembolLabel = new Label("🧙");
        karakterSembolLabel.setFont(Font.font(60));

        ToggleButton kadinBtn = new ToggleButton("👩 Kadın");
        ToggleButton erkekBtn = new ToggleButton("👨 Erkek");
        erkekBtn.setSelected(true);

        ToggleGroup karakterGrubu = new ToggleGroup();
        kadinBtn.setToggleGroup(karakterGrubu);
        erkekBtn.setToggleGroup(karakterGrubu);

        String btnStil = "-fx-background-color: #16213e; -fx-text-fill: white; " +
                         "-fx-border-color: #0f3460; -fx-border-radius: 6; -fx-background-radius: 6;";
        String btnSeciliStil = "-fx-background-color: #0f3460; -fx-text-fill: #e94560; " +
                               "-fx-border-color: #e94560; -fx-border-radius: 6; -fx-background-radius: 6;";

        kadinBtn.setStyle(btnStil);
        erkekBtn.setStyle(btnSeciliStil);

        kadinBtn.setOnAction(e -> {
            secilenKarakter = "Kadın";
            karakterSembolLabel.setText("🧝");
            kadinBtn.setStyle(btnSeciliStil);
            erkekBtn.setStyle(btnStil);
        });
        erkekBtn.setOnAction(e -> {
            secilenKarakter = "Erkek";
            karakterSembolLabel.setText("🧙");
            erkekBtn.setStyle(btnSeciliStil);
            kadinBtn.setStyle(btnStil);
        });

        HBox karakterSecimi = new HBox(10, kadinBtn, erkekBtn);
        karakterSecimi.setAlignment(Pos.CENTER);

        // İstatistik etiketleri
        xpLabel = styledLabel("XP: 0", "#a8dadc");
        seviyeLabel = styledLabel("Seviye: 1", "#e9c46a");
        rutbeLabel = styledLabel("Rütbe: Acemi", "#e94560");
        rutbeLabel.setFont(Font.font("System", FontWeight.BOLD, 14));

        xpBar = new ProgressBar(0);
        xpBar.setPrefWidth(300);
        xpBar.setStyle("-fx-accent: #e94560;");

        Label xpIpucu = styledLabel("Her 100 XP'de seviye atlarsın", "#555577");
        xpIpucu.setFont(Font.font(10));

        HBox statSatir = new HBox(20, xpLabel, seviyeLabel, rutbeLabel);
        statSatir.setAlignment(Pos.CENTER);

        VBox panel = new VBox(8,
                karakterSembolLabel,
                karakterSecimi,
                new Separator(),
                statSatir,
                xpBar,
                xpIpucu
        );
        panel.setAlignment(Pos.CENTER);
        panel.setPadding(new Insets(12));
        panel.setStyle("-fx-background-color: #16213e; -fx-background-radius: 10;");

        return panel;
    }

    private VBox gorevFormuOlustur() {
        Label baslik = styledLabel("Yeni Görev", "#a8dadc");
        baslik.setFont(Font.font("System", FontWeight.BOLD, 14));

        TextField gorevAlani = styledTextField("Görev adı (örn: Matematik çalış)");
        TextField amacAlani = styledTextField("Neden yapıyorsun? (örn: Sınav için)");

        Label saatBaslik = styledLabel("Hatırlatma saati:", "#cccccc");

        Spinner<Integer> saatSpinner = new Spinner<>(0, 23, LocalTime.now().getHour());
        Spinner<Integer> dakikaSpinner = new Spinner<>(0, 59, 0);
        saatSpinner.setPrefWidth(75);
        dakikaSpinner.setPrefWidth(75);
        saatSpinner.setStyle("-fx-background-color: #0f3460; -fx-text-fill: white;");
        dakikaSpinner.setStyle("-fx-background-color: #0f3460; -fx-text-fill: white;");

        Label araLabel = styledLabel(":", "#aaaaaa");
        araLabel.setFont(Font.font("System", FontWeight.BOLD, 18));

        HBox saatSatiri = new HBox(6, saatSpinner, araLabel, dakikaSpinner);
        saatSatiri.setAlignment(Pos.CENTER_LEFT);

        Button ekleBtn = new Button("+ Görev Ekle");
        ekleBtn.setStyle("-fx-background-color: #e94560; -fx-text-fill: white; " +
                         "-fx-font-weight: bold; -fx-background-radius: 8; " +
                         "-fx-cursor: hand; -fx-padding: 8 20;");
        ekleBtn.setMaxWidth(Double.MAX_VALUE);

        ekleBtn.setOnAction(e -> {
            String gorev = gorevAlani.getText().trim();
            String amac = amacAlani.getText().trim();

            if (gorev.isEmpty()) {
                sallama(gorevAlani);
                return;
            }

            int saat = saatSpinner.getValue();
            int dakika = dakikaSpinner.getValue();
            String hedefSaat = String.format("%02d:%02d", saat, dakika);

            gorevEkle(gorev, amac, hedefSaat);
            gorevAlani.clear();
            amacAlani.clear();
        });

        VBox panel = new VBox(8,
                baslik,
                gorevAlani,
                amacAlani,
                saatBaslik,
                saatSatiri,
                ekleBtn
        );
        panel.setPadding(new Insets(12));
        panel.setStyle("-fx-background-color: #16213e; -fx-background-radius: 10;");

        return panel;
    }

    private VBox gorevListesiPaneliOlustur() {
        Label baslik = styledLabel("Görev Listesi", "#a8dadc");
        baslik.setFont(Font.font("System", FontWeight.BOLD, 14));

        gorevListesi = new VBox(6);

        Label bosLabel = styledLabel("Henüz görev yok. Ekle, başla.", "#555577");
        bosLabel.setFont(Font.font(11));
        gorevListesi.getChildren().add(bosLabel);

        VBox panel = new VBox(8, baslik, gorevListesi);
        panel.setPadding(new Insets(12));
        panel.setStyle("-fx-background-color: #16213e; -fx-background-radius: 10;");

        return panel;
    }

    // --- İş Mantığı ---

    private void gorevEkle(String gorev, String amac, String hedefSaat) {
        // hatırlatıcı listesine ekle: [isim, saat, "hayır" = henüz tetiklenmedi]
        hatirlaticilar.add(new String[]{gorev, hedefSaat, "hayır"});

        // UI'da görev satırı oluştur
        HBox satir = gorevSatiriOlustur(gorev, amac, hedefSaat);
        gorevListesi.getChildren().remove(0); // varsa "henüz görev yok" labelı kaldır
        gorevListesi.getChildren().add(0, satir);

        // Görev eklemek XP vermiyor; tamamlamak verir
        // (orijinalde eklince XP veriliyordu, mantıken yanlış)
    }

    private HBox gorevSatiriOlustur(String gorev, String amac, String hedefSaat) {
        Circle nokta = new Circle(5, Color.web("#e94560"));

        String metinAmac = amac.isEmpty() ? "" : " — " + amac;
        Label gorevLabel = new Label("📝 " + gorev + metinAmac);
        gorevLabel.setTextFill(Color.web("#dddddd"));
        gorevLabel.setWrapText(true);
        gorevLabel.setMaxWidth(280);

        Label saatLabel = new Label("⏰ " + hedefSaat);
        saatLabel.setTextFill(Color.web("#a8dadc"));
        saatLabel.setFont(Font.font(11));

        Button tamamlaBtn = new Button("✓");
        tamamlaBtn.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; " +
                            "-fx-background-radius: 4; -fx-cursor: hand; -fx-padding: 3 8;");

        Button silBtn = new Button("✕");
        silBtn.setStyle("-fx-background-color: #555; -fx-text-fill: #ccc; " +
                        "-fx-background-radius: 4; -fx-cursor: hand; -fx-padding: 3 8;");

        HBox butonlar = new HBox(4, tamamlaBtn, silBtn);

        VBox solTaraf = new VBox(2, gorevLabel, saatLabel);
        HBox.setHgrow(solTaraf, Priority.ALWAYS);

        HBox satir = new HBox(8, nokta, solTaraf, butonlar);
        satir.setAlignment(Pos.CENTER_LEFT);
        satir.setPadding(new Insets(8));
        satir.setStyle("-fx-background-color: #0f3460; -fx-background-radius: 8;");

        tamamlaBtn.setOnAction(e -> {
            gorevTamamla(satir, gorev);
        });

        silBtn.setOnAction(e -> {
            gorevSil(satir, gorev, hedefSaat);
        });

        return satir;
    }

    private void gorevTamamla(HBox satir, String gorevAdi) {
        // Tamamlanan görevi sarıya çek, butonları kaldır
        satir.setStyle("-fx-background-color: #1a472a; -fx-background-radius: 8;");
        satir.getChildren().removeIf(n -> n instanceof HBox); // butonları kaldır

        Label tamamLabel = new Label("✅ Tamamlandı");
        tamamLabel.setTextFill(Color.web("#2ecc71"));
        tamamLabel.setFont(Font.font(11));
        satir.getChildren().add(tamamLabel);

        xpKazan(50);

        // Bilgi alert'i
        Platform.runLater(() -> {
            Alert bilgi = new Alert(Alert.AlertType.INFORMATION);
            bilgi.setTitle("Tebrikler!");
            bilgi.setHeaderText(gorevAdi + " tamamlandı");
            bilgi.setContentText("+50 XP kazandın! Toplam: " + xp + " XP");
            bilgi.showAndWait();
        });
    }

    private void gorevSil(HBox satir, String gorevAdi, String hedefSaat) {
        gorevListesi.getChildren().remove(satir);

        // hatırlatıcı listesinden de çıkar
        hatirlaticilar.removeIf(h -> h[0].equals(gorevAdi) && h[1].equals(hedefSaat));

        if (gorevListesi.getChildren().isEmpty()) {
            Label bosLabel = styledLabel("Henüz görev yok. Ekle, başla.", "#555577");
            bosLabel.setFont(Font.font(11));
            gorevListesi.getChildren().add(bosLabel);
        }
    }

    private void xpKazan(int miktar) {
        xp += miktar;
        xpLabel.setText("XP: " + xp);

        int yeniSeviye = (xp / 100) + 1;
        if (yeniSeviye != seviye) {
            seviye = yeniSeviye;
            seviyeLabel.setText("Seviye: " + seviye);
            seviyeAtlaUyarisi();
        }

        rutbeGuncelle();

        double progress = (xp % 100) / 100.0;
        xpBar.setProgress(progress);
    }

    private void rutbeGuncelle() {
        String yeniRutbe;
        if (seviye >= 10) yeniRutbe = "Efsane";
        else if (seviye >= 6) yeniRutbe = "Usta";
        else if (seviye >= 3) yeniRutbe = "Çalışkan";
        else yeniRutbe = "Acemi";

        rutbeLabel.setText("Rütbe: " + yeniRutbe);
    }

    private void seviyeAtlaUyarisi() {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Seviye Atladın!");
            alert.setHeaderText("Seviye " + seviye + " oldun!");
            alert.setContentText("Harika iş çıkarıyorsun. Devam et!");
            alert.showAndWait();
        });
    }

    private void zamanSayiciBaslat() {
        zamanSayici = new Timer(true);
        zamanSayici.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                String simdikiSaat = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));

                for (String[] h : hatirlaticilar) {
                    // sadece bir kez tetikle
                    if (h[1].equals(simdikiSaat) && h[2].equals("hayır")) {
                        h[2] = "evet"; // bir daha çalışmasın
                        final String gorevAdi = h[0];
                        Platform.runLater(() -> hatirlaticiGoster(gorevAdi));
                    }
                }
            }
        }, 0, 30_000); // her 30 saniyede bir kontrol et
    }

    private void hatirlaticiGoster(String gorevAdi) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Görev Zamanı!");
        alert.setHeaderText("Unutmadan: " + gorevAdi);
        alert.setContentText("Belirlediğin saate geldi. Hadi başla!");
        alert.showAndWait();
    }

    // --- Yardımcı Metotlar ---

    private Label styledLabel(String metin, String renk) {
        Label l = new Label(metin);
        l.setTextFill(Color.web(renk));
        return l;
    }

    private TextField styledTextField(String ipucu) {
        TextField tf = new TextField();
        tf.setPromptText(ipucu);
        tf.setStyle("-fx-background-color: #0f3460; -fx-text-fill: white; " +
                    "-fx-prompt-text-fill: #667799; -fx-background-radius: 6; " +
                    "-fx-border-color: transparent;");
        return tf;
    }

    // hafif titretme efekti - boş bırakılan alanlara
    private void sallama(TextField alan) {
        double basX = alan.getLayoutX();
        for (int i = 0; i < 4; i++) {
            final int adim = i;
            new Timer(true).schedule(new TimerTask() {
                @Override
                public void run() {
                    Platform.runLater(() -> alan.setTranslateX(adim % 2 == 0 ? 5 : -5));
                }
            }, adim * 60L);
        }
        new Timer(true).schedule(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> alan.setTranslateX(0));
            }
        }, 250);
    }
}
